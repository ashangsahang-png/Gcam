# Rasa Cam

Aplikasi kamera Android dengan sistem preset/config. Foto diproses setelah dijepret
(eksposur, kontras, highlight, bayangan, saturasi, suhu warna, tint, ketajaman, vinyet, grain).
Config bisa diimpor dari file JSON atau XML config LMC/GCam (hanya key yang terbaca).

## Build lewat GitHub Actions
1. Buat repo baru di GitHub, lalu unggah seluruh isi folder ini.
2. Buka tab **Actions**. Workflow "Build APK" jalan otomatis setiap push (atau klik *Run workflow*).
3. Setelah selesai, unduh APK dari bagian **Artifacts** pada halaman run.
4. Untuk rilis: `git tag v1.0 && git push origin v1.0`. APK terlampir di tab Releases.

APK yang dihasilkan adalah debug build (ditandatangani kunci debug), cukup untuk dipasang di HP.

## Build lokal
Buka folder di Android Studio, atau jalankan `gradle assembleDebug` (Gradle 8.7, JDK 17).

## Format config JSON
```json
{ "name": "Contoh", "exposure": 4, "contrast": 12, "highlights": -15, "shadows": 18,
  "saturation": 14, "temperature": 6, "tint": 0, "sharpness": 20, "vignette": 0, "grain": 0,
  "satR": 1.0, "satG": 1.0, "satB": 1.0 }
```
