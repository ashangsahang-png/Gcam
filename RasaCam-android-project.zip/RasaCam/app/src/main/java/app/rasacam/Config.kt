package app.rasacam

import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

/** Preset tampilan. Nilai -100..100 (sharpness, vignette, grain: 0..100). satR/G/B = pengali saturasi per kanal. */
data class Config(
    val name: String,
    val exposure: Float = 0f, val contrast: Float = 0f, val highlights: Float = 0f,
    val shadows: Float = 0f, val saturation: Float = 0f, val temperature: Float = 0f,
    val tint: Float = 0f, val sharpness: Float = 0f, val vignette: Float = 0f, val grain: Float = 0f,
    val satR: Float = 1f, val satG: Float = 1f, val satB: Float = 1f
) {
    companion object {
        val BUILTIN = listOf(
            Config("Asli"),
            Config("iPhone", exposure = 4f, contrast = 12f, highlights = -15f, shadows = 18f, saturation = 14f, temperature = 6f, sharpness = 20f),
            Config("Pixel", contrast = 18f, highlights = -24f, shadows = 10f, saturation = 6f, temperature = -4f, sharpness = 38f),
            Config("Samsung", exposure = 6f, contrast = 8f, shadows = 6f, saturation = 30f, temperature = -2f, sharpness = 32f),
            Config("Film", contrast = 10f, highlights = -10f, shadows = 12f, saturation = -14f, temperature = 14f, tint = 4f, vignette = 28f, grain = 34f)
        )

        fun fromJson(text: String): Config {
            val o = JSONObject(text)
            fun f(k: String, d: Float = 0f) = o.optDouble(k, d.toDouble()).toFloat()
            return Config(
                o.optString("name", "Impor"), f("exposure"), f("contrast"), f("highlights"), f("shadows"),
                f("saturation"), f("temperature"), f("tint"), f("sharpness"), f("vignette"), f("grain"),
                f("satR", 1f), f("satG", 1f), f("satB", 1f)
            )
        }

        /** Membaca config LMC/GCam (XML SharedPreferences). Hanya key yang terbaca; patch hex lib_* diabaikan. */
        fun fromLmcXml(text: String, name: String): Config {
            val m = HashMap<String, String>()
            val p = Xml.newPullParser()
            p.setInput(StringReader(text))
            var e = p.eventType
            while (e != XmlPullParser.END_DOCUMENT) {
                if (e == XmlPullParser.START_TAG && p.name == "string") {
                    val n = p.getAttributeValue(null, "name")
                    if (n != null) m[n] = p.nextText()
                }
                e = p.next()
            }
            fun v(k: String) = m[k]?.toFloatOrNull() ?: 1f
            val all = v("pref_satCCT_key")
            return Config(name, satR = v("pref_satCCT_R_key") * all, satG = v("pref_satCCT_G_key") * all, satB = v("pref_satCCT_B_key") * all)
        }
    }
}
