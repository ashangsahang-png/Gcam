package app.rasacam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private lateinit var adapter: ArrayAdapter<String>
    private var capture: ImageCapture? = null
    private val presets = Config.BUILTIN.toMutableList()
    private var current = presets[1]

    private val pickConfig = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) importConfig(u) }
    private val askCam = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else status.text = "Izin kamera ditolak"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val mp = FrameLayout.LayoutParams.MATCH_PARENT
        val root = FrameLayout(this)
        preview = PreviewView(this)
        root.addView(preview, FrameLayout.LayoutParams(mp, mp))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEEFFFFFF.toInt()); setPadding(32, 24, 32, 48)
        }
        status = TextView(this).apply { text = "Preset: ${current.name}"; setTextColor(Color.BLACK) }
        spinner = Spinner(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets.map { it.name }.toMutableList())
        spinner.adapter = adapter
        spinner.setSelection(1)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                current = presets[pos]; status.text = "Preset: ${current.name}"
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val imp = Button(this).apply { text = "Impor config"; setOnClickListener { pickConfig.launch(arrayOf("*/*")) } }
        val shoot = Button(this).apply { text = "Jepret"; setOnClickListener { shoot() } }
        row.addView(imp, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(shoot, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(status); bar.addView(spinner); bar.addView(row)
        root.addView(bar, FrameLayout.LayoutParams(mp, -2, Gravity.BOTTOM))
        setContentView(root)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else askCam.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun shoot() {
        val cap = capture ?: return
        val file = File(cacheDir, "raw.jpg")
        status.text = "Mengambil foto..."
        cap.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(), ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) { process(file, current) }
                override fun onError(e: ImageCaptureException) { status.text = "Gagal: ${e.message}" }
            })
    }

    private fun process(file: File, cfg: Config) {
        status.text = "Memproses (${cfg.name})..."
        Thread {
            val msg = try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, o)
                var s = 1
                while (maxOf(o.outWidth, o.outHeight) / s > 4096) s *= 2
                var bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = s })
                val deg = when (ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
                if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                val out = Processor.apply(bmp, cfg)
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "RASA_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RasaCam")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                "Tersimpan di Pictures/RasaCam"
            } catch (t: Throwable) { "Gagal memproses: ${t.message}" }
            runOnUiThread { status.text = msg }
        }.start()
    }

    private fun importConfig(u: Uri) {
        try {
            val text = contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
            val nm = u.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')?.take(24) ?: "Impor"
            val cfg = if (text.trimStart().startsWith("<")) Config.fromLmcXml(text, nm) else Config.fromJson(text)
            presets.add(cfg); adapter.add(cfg.name); spinner.setSelection(presets.size - 1)
            status.text = "Config dimuat: ${cfg.name}"
        } catch (t: Throwable) { status.text = "Config tidak valid: ${t.message}" }
    }
}
