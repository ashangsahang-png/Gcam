package app.rasacam

import android.graphics.Bitmap
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.random.Random

object Processor {
    fun apply(src: Bitmap, c: Config): Bitmap {
        val w = src.width; val h = src.height
        var px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        if (c.sharpness > 0f) px = sharpen(px, w, h, c.sharpness / 100f * 0.9f)
        val ex = 2f.pow(c.exposure / 50f)
        val ct = 1f + c.contrast / 100f * 0.8f
        val t = c.temperature / 100f; val ti = c.tint / 100f
        val hi = c.highlights / 100f * 0.35f; val sh = c.shadows / 100f * 0.35f
        val sat = 1f + c.saturation / 100f
        val vg = c.vignette / 100f * 0.7f; val gr = c.grain / 100f * 0.16f
        val cx = w / 2f; val cy = h / 2f; val md = hypot(cx, cy)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x; val p = px[i]
            var r = ((p shr 16) and 255) / 255f * ex
            var g = ((p shr 8) and 255) / 255f * ex
            var b = (p and 255) / 255f * ex
            r *= 1f + t * 0.18f + ti * 0.04f; b *= 1f - t * 0.18f + ti * 0.04f; g *= 1f - ti * 0.1f
            val l = (0.2126f * r + 0.7152f * g + 0.0722f * b).coerceIn(0f, 1f)
            val add = sh * (1f - l) * (1f - l) + hi * l * l
            r = (r + add - 0.5f) * ct + 0.5f; g = (g + add - 0.5f) * ct + 0.5f; b = (b + add - 0.5f) * ct + 0.5f
            val gy = 0.2126f * r + 0.7152f * g + 0.0722f * b
            r = gy + (r - gy) * sat * c.satR; g = gy + (g - gy) * sat * c.satG; b = gy + (b - gy) * sat * c.satB
            if (vg > 0f) { val d = hypot(x - cx, y - cy) / md; val f = 1f - vg * d * d; r *= f; g *= f; b *= f }
            if (gr > 0f) { val n = (Random.nextFloat() - 0.5f) * gr; r += n; g += n; b += n }
            px[i] = (0xFF shl 24) or (to8(r) shl 16) or (to8(g) shl 8) or to8(b)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun to8(v: Float) = (v.coerceIn(0f, 1f) * 255f + 0.5f).toInt()

    private fun sharpen(s: IntArray, w: Int, h: Int, a: Float): IntArray {
        val o = s.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            var out = 0xFF shl 24
            for (k in 0..2) {
                val sh = 16 - 8 * k
                val c = (s[i] shr sh) and 255
                val v = c + a * (4 * c - ((s[i - 1] shr sh) and 255) - ((s[i + 1] shr sh) and 255) - ((s[i - w] shr sh) and 255) - ((s[i + w] shr sh) and 255))
                out = out or (v.toInt().coerceIn(0, 255) shl sh)
            }
            o[i] = out
        }
        return o
    }
}
